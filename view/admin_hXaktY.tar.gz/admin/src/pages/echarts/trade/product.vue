<template>
    
</template>

<script>
export default {
    name: "product"
}
</script>

<style scoped>

</style>