<template>
    <div>
        <div class="i-layout-page-header">
            <PageHeader class="product_tabs" title="配置" hidden-breadcrumb></PageHeader>
        </div>
        <Card :bordered="false" dis-hover class="ivu-mt">
            后台from表单
        </Card>
    </div>
</template>

<script>
    export default {
        name: 'systemConfig'
    }
</script>

<style scoped>

</style>
