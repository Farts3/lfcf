(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods_details/components/specs/index"],{"403c":function(n,t,e){"use strict";var c=e("bc59"),u=e.n(c);u.a},"6e9e":function(n,t,e){"use strict";e.r(t);var c=e("71d2"),u=e("6fb9");for(var f in u)["default"].indexOf(f)<0&&function(n){e.d(t,n,(function(){return u[n]}))}(f);e("403c");var o=e("f0c5"),i=Object(o["a"])(u["default"],c["b"],c["c"],!1,null,"116d204a",null,!1,c["a"],void 0);t["default"]=i.exports},"6fb9":function(n,t,e){"use strict";e.r(t);var c=e("fe5d"),u=e.n(c);for(var f in c)["default"].indexOf(f)<0&&function(n){e.d(t,n,(function(){return c[n]}))}(f);t["default"]=u.a},"71d2":function(n,t,e){"use strict";e.d(t,"b",(function(){return c})),e.d(t,"c",(function(){return u})),e.d(t,"a",(function(){}));var c=function(){var n=this.$createElement;this._self._c},u=[]},bc59:function(n,t,e){},fe5d:function(n,t,e){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var c={props:{specsInfo:{type:Object,default:function(){}}},data:function(){return{}},mounted:function(){},methods:{closeSpecs:function(){this.$emit("myevent")}}};t.default=c}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods_details/components/specs/index-create-component',
    {
        'pages/goods_details/components/specs/index-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("6e9e"))
        })
    },
    [['pages/goods_details/components/specs/index-create-component']]
]);
