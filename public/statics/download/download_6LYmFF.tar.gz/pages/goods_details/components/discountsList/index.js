(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods_details/components/discountsList/index"],{"0d59":function(t,n,e){"use strict";e.r(n);var r=e("0e81"),u=e("79d0");for(var a in u)["default"].indexOf(a)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(a);e("e6ac");var i=e("f0c5"),o=Object(i["a"])(u["default"],r["b"],r["c"],!1,null,"0e97edf7",null,!1,r["a"],void 0);n["default"]=o.exports},"0e81":function(t,n,e){"use strict";e.d(n,"b",(function(){return r})),e.d(n,"c",(function(){return u})),e.d(n,"a",(function(){}));var r=function(){var t=this,n=t.$createElement,e=(t._self._c,t.__map(t.discountsData,(function(n,e){var r=t.__get_orig(n),u=t.__map(n.products,(function(n,e){var r=t.__get_orig(n),u=n.title.substring(0,5);return{$orig:r,g0:u}}));return{$orig:r,l0:u}})));t.$mp.data=Object.assign({},{$root:{l1:e}})},u=[]},"79d0":function(t,n,e){"use strict";e.r(n);var r=e("fa60"),u=e.n(r);for(var a in r)["default"].indexOf(a)<0&&function(t){e.d(n,t,(function(){return r[t]}))}(a);n["default"]=u.a},9505:function(t,n,e){},e6ac:function(t,n,e){"use strict";var r=e("9505"),u=e.n(r);u.a},fa60:function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var r={data:function(){return{}},props:{discountsData:{type:Array,default:function(){return[]}}}};n.default=r}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods_details/components/discountsList/index-create-component',
    {
        'pages/goods_details/components/discountsList/index-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("0d59"))
        })
    },
    [['pages/goods_details/components/discountsList/index-create-component']]
]);
