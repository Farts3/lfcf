(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/index/components/blankPage"],{"0985":function(t,n,e){"use strict";e.d(n,"b",(function(){return a})),e.d(n,"c",(function(){return i})),e.d(n,"a",(function(){}));var a=function(){var t=this.$createElement;this._self._c},i=[]},"3b9f":function(t,n,e){"use strict";e.r(n);var a=e("0985"),i=e("eb5f");for(var o in i)["default"].indexOf(o)<0&&function(t){e.d(n,t,(function(){return i[t]}))}(o);e("e8a2");var f=e("f0c5"),u=Object(f["a"])(i["default"],a["b"],a["c"],!1,null,null,null,!1,a["a"],void 0);n["default"]=u.exports},"3fcb":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={name:"blankPage",props:{dataConfig:{type:Object,default:function(){}},isSortType:{type:String|Number,default:0}},data:function(){return{bgColor:this.dataConfig.bgColor.color[0].item,heightConfig:this.dataConfig.heightConfig.val}},created:function(){},methods:{}};n.default=a},b841:function(t,n,e){},e8a2:function(t,n,e){"use strict";var a=e("b841"),i=e.n(a);i.a},eb5f:function(t,n,e){"use strict";e.r(n);var a=e("3fcb"),i=e.n(a);for(var o in a)["default"].indexOf(o)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(o);n["default"]=i.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/index/components/blankPage-create-component',
    {
        'pages/index/components/blankPage-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("3b9f"))
        })
    },
    [['pages/index/components/blankPage-create-component']]
]);
