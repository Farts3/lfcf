require('../../common/vendor.js');(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/goods/lottery/components/showbox"],{"0b5b":function(t,n,e){"use strict";e.d(n,"b",(function(){return a})),e.d(n,"c",(function(){return u})),e.d(n,"a",(function(){}));var a=function(){var t=this.$createElement,n=(this._self._c,["me","user"].includes(this.showMsg.type));this.$mp.data=Object.assign({},{$root:{g0:n}})},u=[]},"0f43":function(t,n,e){"use strict";e.r(n);var a=e("0b5b"),u=e("a01e");for(var o in u)["default"].indexOf(o)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(o);e("baa8");var c=e("f0c5"),r=Object(c["a"])(u["default"],a["b"],a["c"],!1,null,"45a647ec",null,!1,a["a"],void 0);n["default"]=r.exports},"6a9c":function(t,n,e){},"6f6a":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a={data:function(){return{}},props:{showMsg:{type:Object}}};n.default=a},a01e:function(t,n,e){"use strict";e.r(n);var a=e("6f6a"),u=e.n(a);for(var o in a)["default"].indexOf(o)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(o);n["default"]=u.a},baa8:function(t,n,e){"use strict";var a=e("6a9c"),u=e.n(a);u.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/goods/lottery/components/showbox-create-component',
    {
        'pages/goods/lottery/components/showbox-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("0f43"))
        })
    },
    [['pages/goods/lottery/components/showbox-create-component']]
]);
