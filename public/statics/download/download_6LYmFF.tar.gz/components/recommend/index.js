(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/recommend/index"],{2543:function(t,n,e){},"399fd":function(t,n,e){"use strict";e.r(n);var u=e("631a"),a=e.n(u);for(var i in u)["default"].indexOf(i)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(i);n["default"]=a.a},"43a3":function(t,n,e){"use strict";e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return a})),e.d(n,"a",(function(){}));var u=function(){var t=this.$createElement;this._self._c},a=[]},"631a":function(t,n,e){"use strict";(function(t){var u=e("4ea4");Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var a=e("26cb"),i=e("3e4f"),o=u(e("5c3b")),c={computed:(0,a.mapGetters)(["uid"]),props:{hostProduct:{type:Array,default:function(){return[]}}},mixins:[o.default],data:function(){return{}},methods:{goDetail:function(n){(0,i.goShopDetail)(n,this.uid).then((function(e){t.navigateTo({url:"/pages/goods_details/index?id=".concat(n.id)})}))}}};n.default=c}).call(this,e("543d")["default"])},8487:function(t,n,e){"use strict";var u=e("2543"),a=e.n(u);a.a},b281:function(t,n,e){"use strict";e.r(n);var u=e("43a3"),a=e("399fd");for(var i in a)["default"].indexOf(i)<0&&function(t){e.d(n,t,(function(){return a[t]}))}(i);e("8487");var o=e("f0c5"),c=Object(o["a"])(a["default"],u["b"],u["c"],!1,null,"b1f6b372",null,!1,u["a"],void 0);n["default"]=c.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/recommend/index-create-component',
    {
        'components/recommend/index-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("b281"))
        })
    },
    [['components/recommend/index-create-component']]
]);
