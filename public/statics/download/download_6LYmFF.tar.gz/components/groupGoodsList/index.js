(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["components/groupGoodsList/index"],{1223:function(t,n,e){"use strict";e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return o})),e.d(n,"a",(function(){}));var u=function(){var t=this.$createElement,n=(this._self._c,this.goodsList.length);this.$mp.data=Object.assign({},{$root:{g0:n}})},o=[]},"35ba":function(t,n,e){"use strict";Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var u=e("26cb"),o={props:{goodsList:{type:Array,default:function(){return[]}}},computed:(0,u.mapGetters)(["uid"])};n.default=o},"8baf":function(t,n,e){"use strict";var u=e("c1d5"),o=e.n(u);o.a},a294:function(t,n,e){"use strict";e.r(n);var u=e("1223"),o=e("db47");for(var a in o)["default"].indexOf(a)<0&&function(t){e.d(n,t,(function(){return o[t]}))}(a);e("8baf");var r=e("f0c5"),i=Object(r["a"])(o["default"],u["b"],u["c"],!1,null,"dbf550b0",null,!1,u["a"],void 0);n["default"]=i.exports},c1d5:function(t,n,e){},db47:function(t,n,e){"use strict";e.r(n);var u=e("35ba"),o=e.n(u);for(var a in u)["default"].indexOf(a)<0&&function(t){e.d(n,t,(function(){return u[t]}))}(a);n["default"]=o.a}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'components/groupGoodsList/index-create-component',
    {
        'components/groupGoodsList/index-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("a294"))
        })
    },
    [['components/groupGoodsList/index-create-component']]
]);
